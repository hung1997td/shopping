'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('quote', 'de', {
        title: 'Zitat'
    });
})(CKEDITOR);
