'use strict';

(function (CKEDITOR) {
    CKEDITOR.plugins.setLang('quote', 'en', {
        title: 'Quote'
    });
})(CKEDITOR);
